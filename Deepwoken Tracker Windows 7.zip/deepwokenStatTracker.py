from audioop import mul
from lib2to3.refactor import MultiprocessingUnsupported
from tkinter import *
from json import dump,loads

#Save/load json Functions

def load(file):
    try:
        with open(file) as f:
            data = f.read()
        try:
            slotData = loads(data)
        except:
            slotData = {"A": {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0, "Flamecharm": 0, "Frostdraw": 0, "Thundercall": 0, "Galebreathe": 0, "Shadowcast": 0}}
    except:
        slotData = {"A": {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0, "Flamecharm": 0, "Frostdraw": 0, "Thundercall": 0, "Galebreathe": 0, "Shadowcast": 0}}
    return slotData

def save(file, data):
    dump(data, open(file, "w"))
    

#Stat button functions
def clicked(pressInfo):
    #globalling stats int values
    global strength, fortitude, agility, intelligence, willpower, charisma, heavy, medium, light, flamecharm, frostdraw, thundercall, galebreathe, shadowcast, investmentPoints
    
    used = True
    #checking for + or -
    pos = (pressInfo.x,pressInfo.y)
    
    #finds what stat and changes gui to updated version
    if pos[0] <= 200:
        multiplier = -1 if pos[0] < 170 else 1
        if (multiplier == -1 and investmentPoints < 327) or (multiplier == 1 and investmentPoints > 0):
            if pos[1] <= 127:
                strength += 1*multiplier
                if strength > 102:
                    strength = 102
                    used = False
                if strength < 0:
                    strength = 0
                    used = False
                bgCanvas.itemconfig(strengthStat, text=str(strength))
            elif pos[1] <= 149:
                fortitude += 1*multiplier
                if fortitude > 102:
                    fortitude = 102
                    used = False
                if fortitude < 0:
                    fortitude = 0
                    used = False

                bgCanvas.itemconfig(fortitudeStat, text=str(fortitude))
            elif pos[1] <= 171:
                agility += 1*multiplier
                if agility > 102:
                    agility = 102
                    used = False
                if agility < 0:
                    agility = 0
                    used = False
                bgCanvas.itemconfig(agilityStat, text=str(agility))
            elif pos[1] <= 193:
                intelligence += 1*multiplier
                if intelligence > 102:
                    intelligence = 102
                    used = False
                if intelligence < 0:
                    intelligence = 0
                    used = False
                bgCanvas.itemconfig(intelligenceStat, text=str(intelligence))
            elif pos[1] <= 215:
                willpower += 1*multiplier
                if willpower > 102:
                    willpower = 102
                    used = False
                if willpower < 0:
                    willpower = 0
                    used = False
                bgCanvas.itemconfig(willpowerStat, text=str(willpower))
            elif pos[1] <= 237:
                charisma += 1*multiplier
                if charisma > 102:
                    charisma = 102
                    used = False
                if charisma < 0:
                    charisma = 0
                    used = False
                bgCanvas.itemconfig(charismaStat, text=str(charisma))
            elif pos[1] <= 302:
                heavy += 1*multiplier
                if heavy > 100:
                    heavy = 100
                    used = False
                if heavy < 0:
                    heavy = 0
                    used = False
                bgCanvas.itemconfig(heavyStat, text=str(heavy))
            elif pos[1] <= 324:
                medium += 1*multiplier
                if medium > 100:
                    medium = 100
                    used = False
                if medium < 0:
                    medium = 0
                    used = False
                bgCanvas.itemconfig(mediumStat, text=str(medium))
            elif pos[1] <= 346:
                light += 1*multiplier
                if light > 100:
                    light = 100
                    used = False
                if light < 0:
                    light = 0
                    used = False
                bgCanvas.itemconfig(lightStat, text=str(light))
            if used:
                investmentPoints -= 1*multiplier
                bgCanvas.itemconfig(investmentPointsVal, text=str(investmentPoints))
    else:
        multiplier = -1 if pos[0] < 357 else 1
        if (multiplier == -1 and investmentPoints < 327) or (multiplier == 1 and investmentPoints > 0):
            if pos[1] <= 127:
                flamecharm += 1*multiplier
                if flamecharm > 100:
                    flamecharm = 100
                    used = False
                if flamecharm < 0:
                    flamecharm = 0
                    used = False
                bgCanvas.itemconfig(flamecharmStat, text=str(flamecharm))
            elif pos[1] <= 149:
                frostdraw += 1*multiplier
                if frostdraw > 100:
                    frostdraw = 100
                    used = False
                if frostdraw < 0:
                    frostdraw = 0
                    used = False

                bgCanvas.itemconfig(frostdrawStat, text=str(frostdraw))
            elif pos[1] <= 171:
                thundercall += 1*multiplier
                if thundercall > 100:
                    thundercall = 100
                    used = False
                if thundercall < 0:
                    thundercall = 0
                    used = False
                bgCanvas.itemconfig(thundercallStat, text=str(thundercall))
            elif pos[1] <= 193:
                galebreathe += 1*multiplier
                if galebreathe > 100:
                    galebreathe = 100
                    used = False
                if galebreathe < 0:
                    galebreathe = 0
                    used = False
                bgCanvas.itemconfig(galebreatheStat, text=str(galebreathe))
            elif pos[1] <= 215:
                shadowcast += 1*multiplier
                if shadowcast > 100:
                    shadowcast = 100
                    used = False
                if shadowcast < 0:
                    shadowcast = 0
                    used = False
                bgCanvas.itemconfig(shadowcastStat, text=str(shadowcast))
        #removes/adds investment point if the stat pressed isn't minned/maxed
            if used:
                investmentPoints -= 1*multiplier
                bgCanvas.itemconfig(investmentPointsVal, text=str(investmentPoints))

#Slot change function for left/right button
def slotChange(pressInfo):
    global allSlots, currentSlot, slotData
    global strength, fortitude, agility, intelligence, willpower, charisma, heavy, medium, light, flamecharm, frostdraw, thundercall, galebreathe, shadowcast, investmentPoints

    currentDat = {"Strength": strength, "Fortitude": fortitude, "Agility": agility, "Intelligence": intelligence, "Willpower": willpower, "Charisma": charisma, "Heavy": heavy, "Medium": medium, "Light": light, "Flamecharm": flamecharm, "Frostdraw": frostdraw, "Thundercall": thundercall, "Galebreathe": galebreathe, "Shadowcast": shadowcast}
    slotData[allSlots[currentSlot]] = currentDat
    
    
    pos = (pressInfo.x,pressInfo.y)
    currentSlot += -1 if pos[0] < 200 else 1
    if currentSlot < 0:
        currentSlot = len(allSlots) -1
    if currentSlot > len(allSlots)-1:
        currentSlot = 0
    
    bgCanvas.itemconfig(slotDisplay, text=("Slot", allSlots[currentSlot]))
        
    currentSlotDict = slotData[allSlots[currentSlot]]

    strength = currentSlotDict["Strength"]
    fortitude = currentSlotDict["Fortitude"]
    agility = currentSlotDict["Agility"]
    intelligence = currentSlotDict["Intelligence"]
    willpower = currentSlotDict["Willpower"]
    charisma = currentSlotDict["Charisma"]

    heavy = currentSlotDict["Heavy"]
    medium = currentSlotDict["Medium"]
    light = currentSlotDict["Light"]
    
    flamecharm = currentSlotDict["Flamecharm"]
    frostdraw = currentSlotDict["Frostdraw"]
    thundercall = currentSlotDict["Thundercall"]
    galebreathe = currentSlotDict["Galebreathe"]
    shadowcast = currentSlotDict["Shadowcast"]
    
    investmentPoints = 327-strength-fortitude-agility-intelligence-willpower-charisma-heavy-medium-light-flamecharm-frostdraw-thundercall-galebreathe-shadowcast
    
    
    bgCanvas.itemconfig(strengthStat, text=str(strength))
    bgCanvas.itemconfig(fortitudeStat, text=str(fortitude))
    bgCanvas.itemconfig(agilityStat, text=str(agility))
    bgCanvas.itemconfig(intelligenceStat, text=str(intelligence))
    bgCanvas.itemconfig(willpowerStat, text=str(willpower))
    bgCanvas.itemconfig(charismaStat, text=str(charisma))
    bgCanvas.itemconfig(heavyStat, text=str(heavy))
    bgCanvas.itemconfig(mediumStat, text=str(medium))
    bgCanvas.itemconfig(lightStat, text=str(light))
    bgCanvas.itemconfig(flamecharmStat, text=str(flamecharm))
    bgCanvas.itemconfig(frostdrawStat, text=str(frostdraw))
    bgCanvas.itemconfig(thundercallStat, text=str(thundercall))
    bgCanvas.itemconfig(galebreatheStat, text=str(galebreathe))
    bgCanvas.itemconfig(shadowcastStat, text=str(shadowcast))
    bgCanvas.itemconfig(investmentPointsVal, text=str(investmentPoints))
        

#Wipe button function
def wipe(pressInfo):
    global strength
    global fortitude
    global agility
    global intelligence
    global willpower
    global charisma
    
    global heavy
    global medium
    global light
    
    global flamecharm
    global frostdraw
    global thundercall
    global galebreathe
    global shadowcast
    
    global investmentPoints
    
    strength = 0
    fortitude = 0
    agility = 0
    intelligence = 0
    willpower = 0
    charisma = 0
    heavy = 0
    medium = 0
    light = 0
    flamecharm = 0
    frostdraw = 0
    thundercall = 0
    galebreathe = 0
    shadowcast = 0
    investmentPoints = 327
    
    bgCanvas.itemconfig(strengthStat, text=str(strength))
    bgCanvas.itemconfig(fortitudeStat, text=str(fortitude))
    bgCanvas.itemconfig(agilityStat, text=str(agility))
    bgCanvas.itemconfig(intelligenceStat, text=str(intelligence))
    bgCanvas.itemconfig(willpowerStat, text=str(willpower))
    bgCanvas.itemconfig(charismaStat, text=str(charisma))
    bgCanvas.itemconfig(heavyStat, text=str(heavy))
    bgCanvas.itemconfig(mediumStat, text=str(medium))
    bgCanvas.itemconfig(lightStat, text=str(light))
    bgCanvas.itemconfig(flamecharmStat, text=str(flamecharm))
    bgCanvas.itemconfig(frostdrawStat, text=str(frostdraw))
    bgCanvas.itemconfig(thundercallStat, text=str(thundercall))
    bgCanvas.itemconfig(galebreatheStat, text=str(galebreathe))
    bgCanvas.itemconfig(shadowcastStat, text=str(shadowcast))
    bgCanvas.itemconfig(investmentPointsVal, text=str(investmentPoints))
    
#Add slot button function
def addSlot(pressInfo):
    global allSlots, currentSlot, slotData
    global strength, fortitude, agility, intelligence, willpower, charisma, heavy, medium, light, investmentPoints
    
    currentDat = {"Strength": strength, "Fortitude": fortitude, "Agility": agility, "Intelligence": intelligence, "Willpower": willpower, "Charisma": charisma, "Heavy": heavy, "Medium": medium, "Light": light, "Flamecharm": 0, "Frostdraw": 0, "Thundercall": 0, "Galebreathe": 0, "Shadowcast": 0}
    slotData[allSlots[currentSlot]] = currentDat
    
    if allSlots[len(allSlots)-1] == "Z": return
    newSlot = chr(ord(allSlots[len(allSlots)-1])+1)
    currentSlotDict = {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0, "Flamecharm": 0, "Frostdraw": 0, "Thundercall": 0, "Galebreathe": 0, "Shadowcast": 0}
    slotData[newSlot] = currentSlotDict
    allSlots.append(newSlot)
    currentSlot = len(allSlots)-1
    
    strength = 0
    fortitude = 0
    agility = 0
    intelligence = 0
    willpower = 0
    charisma = 0

    heavy = 0
    medium = 0
    light = 0
    
    flamecharm = 0
    frostdraw = 0
    thundercall = 0
    galebreathe = 0
    shadowcast = 0
    
    investmentPoints = 327
    
    
    bgCanvas.itemconfig(slotDisplay, text=("Slot",allSlots[currentSlot]))
    bgCanvas.itemconfig(strengthStat, text=str(strength))
    bgCanvas.itemconfig(fortitudeStat, text=str(fortitude))
    bgCanvas.itemconfig(agilityStat, text=str(agility))
    bgCanvas.itemconfig(intelligenceStat, text=str(intelligence))
    bgCanvas.itemconfig(willpowerStat, text=str(willpower))
    bgCanvas.itemconfig(charismaStat, text=str(charisma))
    bgCanvas.itemconfig(heavyStat, text=str(heavy))
    bgCanvas.itemconfig(mediumStat, text=str(medium))
    bgCanvas.itemconfig(lightStat, text=str(light))
    bgCanvas.itemconfig(flamecharmStat, text=str(flamecharm))
    bgCanvas.itemconfig(frostdrawStat, text=str(frostdraw))
    bgCanvas.itemconfig(thundercallStat, text=str(thundercall))
    bgCanvas.itemconfig(galebreatheStat, text=str(galebreathe))
    bgCanvas.itemconfig(shadowcastStat, text=str(shadowcast))
    bgCanvas.itemconfig(investmentPointsVal, text=str(investmentPoints))

    
    

#makes window
root = Tk()
root.title("TkinterTest")
root.call("wm","iconphoto",root._w, PhotoImage(file="icon.png"))
root.geometry("402x447")
root.resizable(width=False, height=False)

#defining initial values


'''slotData = {"A": {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0},
            "B": {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0},
            "C": {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0},
            "D": {"Strength": 0, "Fortitude": 0, "Agility": 0, "Intelligence": 0, "Willpower": 0, "Charisma": 0, "Heavy": 0, "Medium": 0, "Light": 0}}
'''

slotData = load("data.json")

currentSlot = 0
allSlots = [key for key in slotData]

currentSlotDict = slotData[allSlots[currentSlot]]

strength = currentSlotDict["Strength"]
fortitude = currentSlotDict["Fortitude"]
agility = currentSlotDict["Agility"]
intelligence = currentSlotDict["Intelligence"]
willpower = currentSlotDict["Willpower"]
charisma = currentSlotDict["Charisma"]

heavy = currentSlotDict["Heavy"]
medium = currentSlotDict["Medium"]
light = currentSlotDict["Light"]

flamecharm = currentSlotDict["Flamecharm"]
frostdraw = currentSlotDict["Frostdraw"]
thundercall = currentSlotDict["Thundercall"]
galebreathe = currentSlotDict["Galebreathe"]
shadowcast = currentSlotDict["Shadowcast"]

investmentPoints = 327-strength-fortitude-agility-intelligence-willpower-charisma-heavy-medium-light-flamecharm-frostdraw-thundercall-galebreathe-shadowcast

#makes canvas/background
bg = PhotoImage(file="EmptyStatsBG.png")
bgCanvas = Canvas(root, width=402, height=447)
bgCanvas.pack(fill="both", expand=True)
bgCanvas.create_image(0,0, image=bg, anchor="nw")

#Puts slot name at top
slotDisplay = bgCanvas.create_text(201,22, text=("Slot", allSlots[currentSlot]), font=("myriad pro", "24"), fill="#CACCD4")

#creates default stat values
strengthStat = bgCanvas.create_text(140,119, text=str(strength), font=("myriad pro", "9", "bold"), fill="#383E3A")
fortitudeStat = bgCanvas.create_text(140,141, text=str(fortitude), font=("myriad pro", "9", "bold"), fill="#383E3A")
agilityStat = bgCanvas.create_text(140,163, text=str(agility), font=("myriad pro", "9", "bold"), fill="#383E3A")
intelligenceStat = bgCanvas.create_text(140,185, text=str(intelligence), font=("myriad pro", "9", "bold"), fill="#383E3A")
willpowerStat = bgCanvas.create_text(140,207, text=str(willpower), font=("myriad pro", "9", "bold"), fill="#383E3A")
charismaStat = bgCanvas.create_text(140,229, text=str(charisma), font=("myriad pro", "9", "bold"), fill="#383E3A")
investmentPointsVal = bgCanvas.create_text(262,263, text=str(investmentPoints), font=("myriad pro", "8", "bold"), fill="#DFE0E0")

heavyStat = bgCanvas.create_text(140,294, text=str(heavy), font=("myriad pro", "9", "bold"), fill="#383E3A")
mediumStat = bgCanvas.create_text(140,316, text=str(medium), font=("myriad pro", "9", "bold"), fill="#383E3A")
lightStat = bgCanvas.create_text(140,338, text=str(light), font=("myriad pro", "9", "bold"), fill="#383E3A")

flamecharmStat = bgCanvas.create_text(326,119, text=str(flamecharm), font=("myriad pro", "9", "bold"), fill = "#383E3A")
frostdrawStat = bgCanvas.create_text(326,141, text=str(frostdraw), font=("myriad pro", "9", "bold"), fill = "#383E3A")
thundercallStat = bgCanvas.create_text(326,163, text=str(thundercall), font=("myriad pro", "9", "bold"), fill = "#383E3A")
galebreatheStat = bgCanvas.create_text(326,185, text=str(galebreathe), font=("myriad pro", "9", "bold"), fill = "#383E3A")
shadowcastStat = bgCanvas.create_text(326,207, text=str(shadowcast), font=("myriad pro", "9", "bold"), fill = "#383E3A")

            

#Button sprites
plus = PhotoImage(file="miniplus.png")
minus = PhotoImage(file="miniminus.png")
right = PhotoImage(file="right.png")
left = PhotoImage(file="left.png")
emptyButton = PhotoImage(file="emptybutton.png")
longButton = PhotoImage(file="emptybutton2.png")

#Slot change button images
slotRight = bgCanvas.create_image(380,22,image=right)
slotLeft = bgCanvas.create_image(21,22,image=left)

#Slot change button function givers
bgCanvas.tag_bind(slotRight, "<Button-1>", slotChange)
bgCanvas.tag_bind(slotLeft, "<Button-1>", slotChange)

#Making button images for all stats + and -
plusStrength = bgCanvas.create_image(180,118,image=plus)
plusFortitude = bgCanvas.create_image(180,140,image=plus)
plusAgility = bgCanvas.create_image(180,162,image=plus)
plusIntelligence = bgCanvas.create_image(180,184,image=plus)
plusWillpower = bgCanvas.create_image(180,206,image=plus)
plusCharisma = bgCanvas.create_image(180,228,image=plus)

minusStrength = bgCanvas.create_image(160,118,image=minus)
minusFortitude = bgCanvas.create_image(160,140,image=minus)
minusAgility = bgCanvas.create_image(160,162,image=minus)
minusIntelligence = bgCanvas.create_image(160,184,image=minus)
minusWillpower = bgCanvas.create_image(160,206,image=minus)
minusCharisma = bgCanvas.create_image(160,228,image=minus)

plusHeavy = bgCanvas.create_image(180, 293, image=plus)
plusMedium = bgCanvas.create_image(180, 315, image=plus)
plusLight = bgCanvas.create_image(180, 337, image=plus)

minusHeavy = bgCanvas.create_image(160, 293, image=minus)
minusMedium = bgCanvas.create_image(160, 315, image=minus)
minusLight = bgCanvas.create_image(160, 337, image=minus)

plusFlamecharm = bgCanvas.create_image(366, 118, image=plus)
plusFrostdraw = bgCanvas.create_image(366, 140, image=plus)
plusThundercall = bgCanvas.create_image(366, 162, image=plus)
plusGalebreathe = bgCanvas.create_image(366, 184, image=plus)
plusShadowcast = bgCanvas.create_image(366, 206, image=plus)

minusFlamecharm = bgCanvas.create_image(346, 118, image=minus)
minusFrostdraw = bgCanvas.create_image(346, 140, image=minus)
minusThundercall = bgCanvas.create_image(346, 162, image=minus)
minusGalebreathe = bgCanvas.create_image(346, 184, image=minus)
minusShadowcast = bgCanvas.create_image(346, 206, image=minus)


#Giving button functions to button images
bgCanvas.tag_bind(plusStrength, "<Button-1>", clicked)
bgCanvas.tag_bind(plusFortitude, "<Button-1>", clicked)
bgCanvas.tag_bind(plusAgility, "<Button-1>", clicked)
bgCanvas.tag_bind(plusIntelligence, "<Button-1>", clicked)
bgCanvas.tag_bind(plusWillpower, "<Button-1>", clicked)
bgCanvas.tag_bind(plusCharisma, "<Button-1>", clicked)

bgCanvas.tag_bind(minusStrength, "<Button-1>", clicked)
bgCanvas.tag_bind(minusFortitude, "<Button-1>", clicked)
bgCanvas.tag_bind(minusAgility, "<Button-1>", clicked)
bgCanvas.tag_bind(minusIntelligence, "<Button-1>", clicked)
bgCanvas.tag_bind(minusWillpower, "<Button-1>", clicked)
bgCanvas.tag_bind(minusCharisma, "<Button-1>", clicked)

bgCanvas.tag_bind(plusHeavy, "<Button-1>", clicked)
bgCanvas.tag_bind(plusMedium, "<Button-1>", clicked)
bgCanvas.tag_bind(plusLight, "<Button-1>", clicked)

bgCanvas.tag_bind(minusHeavy, "<Button-1>", clicked)
bgCanvas.tag_bind(minusMedium, "<Button-1>", clicked)
bgCanvas.tag_bind(minusLight, "<Button-1>", clicked)

bgCanvas.tag_bind(plusFlamecharm, "<Button-1>", clicked)
bgCanvas.tag_bind(plusFrostdraw, "<Button-1>", clicked)
bgCanvas.tag_bind(plusThundercall, "<Button-1>", clicked)
bgCanvas.tag_bind(plusGalebreathe, "<Button-1>", clicked)
bgCanvas.tag_bind(plusShadowcast, "<Button-1>", clicked)

bgCanvas.tag_bind(minusFlamecharm, "<Button-1>", clicked)
bgCanvas.tag_bind(minusFrostdraw, "<Button-1>", clicked)
bgCanvas.tag_bind(minusThundercall, "<Button-1>", clicked)
bgCanvas.tag_bind(minusGalebreathe, "<Button-1>", clicked)
bgCanvas.tag_bind(minusShadowcast, "<Button-1>", clicked)

#Wipe button image
wipeButton = bgCanvas.create_image(50,436, image=emptyButton)
wipeText = bgCanvas.create_text(50,436, text="Wipe", font=("myriad pro", "8", "bold"), fill="#CACCD4")

#Wipe button function caller
bgCanvas.tag_bind(wipeButton, "<Button-1>", wipe)
bgCanvas.tag_bind(wipeText, "<Button-1>", wipe)

#Add slot button image
addSlotButton = bgCanvas.create_image(300,436, image=longButton)
addSlotText = bgCanvas.create_text(300,436, text="Add Slot", font=("myriad pro", "8", "bold"), fill="#CACCD4")

#Add slot function caller
bgCanvas.tag_bind(addSlotButton, "<Button-1>", addSlot)
bgCanvas.tag_bind(addSlotText, "<Button-1>", addSlot)


#runs the whole window loop
root.mainloop()

currentDat = {"Strength": strength, "Fortitude": fortitude, "Agility": agility, "Intelligence": intelligence, "Willpower": willpower, "Charisma": charisma, "Heavy": heavy, "Medium": medium, "Light": light, "Flamecharm": flamecharm, "Frostdraw": frostdraw, "Thundercall": thundercall, "Galebreathe": galebreathe, "Shadowcast": shadowcast}
slotData[allSlots[currentSlot]] = currentDat
save("data.json",slotData)